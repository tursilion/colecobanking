// define a static string in ROM
const char * const strBank1 = "Hello from Bank1";


