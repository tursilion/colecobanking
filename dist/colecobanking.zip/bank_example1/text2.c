// define a static string in ROM
const char * const strBank2 = "Hello from Bank2";


